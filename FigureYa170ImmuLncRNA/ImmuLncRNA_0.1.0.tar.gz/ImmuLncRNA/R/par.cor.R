#' @title The partial correlation between genes and lncRNAs
#' @description This is a function for calculating the partial correlation
#'   coefficient and p.value between genes and lncRNAs.
#' @details  \code{par.cor} for calculating the partial correlation
#'   coefficient (PCC) between expression of lncRNA i and gene j by considering
#'   the related sample's tumor purity as a third influence factor based on
#'   pearson correlation.
#' @param mRNA_exp A numeric matrix containing the expression of mRNA with
#'   rownames and colnames
#' @param lncRNA_exp A numeric matrix containing the expression of lncRNA with
#'   rownames and colnames
#' @param tum_pur A vector containing the samples' tumor purity with sample
#'   names
#' @param adjusted A logical value, TRUE represent the expression values in
#'   example were log-transformed and the rows containing many 0 value were
#'   removed.If your expressions were raw, enter FALSE.
#'   
#' @examples
#' lncRNA_exp <- as.matrix(lncRNA_exp)
#' mRNA_exp <- as.matrix(mRNA_exp)
#' turpur_ori <- as.numeric(turpur[,1])
#' names(turpur_ori) <- rownames(turpur)
#' test_res <- par.cor(mRNA_exp,lncRNA_exp,turpur_ori,adjusted=T)
#' 
#' @export

par.cor <- function(mRNA_exp,lncRNA_exp,tum_pur,adjusted){
  fun_mtx_pcr <- function(x,y,z){
    r12=cor(t(x),t(y))
    r13=cor(t(x),z)
    r23=cor(z,t(y))
    r123=r13%*%r23
    rup=r12-r123
    rd1=sqrt(1-r13*r13)
    rd2=sqrt(1-r23*r23)
    rd=rd1%*%rd2
    rrr=rup/rd
    return(rrr)
  }
  inter_samples <- intersect(intersect(colnames(mRNA_exp),colnames(lncRNA_exp)),names(tum_pur))
  inter_tumpur <- tum_pur[inter_samples]
  if(length(inter_tumpur)<1){stop("no same samples")}
  if (adjusted){
    mRNA_exp_inter <- mRNA_exp[,inter_samples]
    lncRNA_exp_inter <- lncRNA_exp[,inter_samples]
  }else{
    mRNA_exp_inter_ori <- mRNA_exp[,inter_samples]
    lncRNA_exp_inter_ori <- lncRNA_exp[,inter_samples]
    mRow30 <- which(apply(mRNA_exp_inter_ori,1,function(v){return((sum(v==0)/length(v))>=0.3)}))
    mRemv <- mRow30
    if(length(mRemv)==0){
      mRNA_out0 <- mRNA_exp_inter_ori
    }else{
      mRNA_out0 <- mRNA_exp_inter_ori[-(mRemv),]
    }
    mRNA_exp_inter <- log2(mRNA_out0+0.001)
    lncRow50 <- which(apply(lncRNA_exp_inter_ori,1,quantile,probs=0.5)==0)
    lncRow90 <- which(apply(lncRNA_exp_inter_ori,1,quantile,probs=0.9)<=0.1)
    lncRemv <- union(lncRow50,lncRow90)
    if(length(lncRemv)==0){
      lncRNA_out0 <- lncRNA_exp_inter_ori
    }else{
      lncRNA_out0 <- lncRNA_exp_inter_ori[-(lncRemv),]
    }
    lncRNA_exp_inter <- log2(lncRNA_out0+0.001)
  }
  n=length(inter_samples)
  gn=1
  pcor <- fun_mtx_pcr(lncRNA_exp_inter,mRNA_exp_inter,inter_tumpur)
  statistic <- pcor*sqrt((n-2-gn)/(1-pcor^2))
  p.value <- 2*pnorm(-abs(statistic))
  rownames(pcor) <- rownames(lncRNA_exp_inter) ; rownames(p.value) <- rownames(lncRNA_exp_inter)
  colnames(pcor) <- rownames(mRNA_exp_inter) ; colnames(p.value) <- rownames(mRNA_exp_inter)
  par.cor.res <- list(pcor,p.value)
  names(par.cor.res) <- c("pcor.value","p.value")
  return(par.cor.res)
}
