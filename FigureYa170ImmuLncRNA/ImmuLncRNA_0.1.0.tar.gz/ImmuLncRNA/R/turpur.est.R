#' @title Caculate samples' tumor purity
#' @description This function provide a method to caculate samples' tumor purity
#'   by giving a related mRNA expression.
#' @details \code{turpur.est} can caculate samples' tumor purity based on the
#'   result from R package \code{estimate}.
#' @param dir_file Character vector representing the directory of the fold which
#'   containing mRNA expression file.
#' @param fileName Character vector, the name of mRNA expression file with gene 
#'   symbol rownames.
#'   
#' @examples
#' mRNA_exp_data <- system.file("extdata","mRNA_test.txt",package = "ImmuLncRNA")
#' mRNA_exp_data # for example this directory and file name
#' dir_name_split <- unlist(strsplit(mRNA_exp_data,"/"))
#' dir_test <- paste(dir_name_split[1:(length(dir_name_split)-1)],collapse = "/")
#' file_test <- dir_name_split[length(dir_name_split)]
#' res_test <- turpur.est(dir_test,file_test)
#' 
#' @export

turpur.est <- function(dir_file,fileName){
  for(pkg in c("estimate")){
    if(!requireNamespace(pkg,quietly=T)){
      stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
           call. = FALSE)
    }
  }
  library(estimate,warn.conflicts=F)
  fold_ori <- getwd()
  setwd(dir_file)
  filterCommonGenes(input.f=fileName, output.f="exp_deal.gct", id="GeneSymbol")
  estimateScore("exp_deal.gct", "estimate_score_all.gct", platform="illumina")
  est_score_all <- readLines("estimate_score_all.gct")
  est_score_split <- unlist(strsplit(est_score_all[grep("ESTIMATEScore",est_score_all)],"\t"))
  est_scores <- as.numeric(est_score_split[3:length(est_score_split)])
  Tumour_purity = cos(0.6049872018+0.0001467884*est_scores)
  samples_split <- unlist(strsplit(est_score_all[grep("NAME",est_score_all)],"\t"))
  samples_name <- samples_split[3:length(samples_split)]
  names(Tumour_purity) <- samples_name
  setwd(fold_ori)
  return(Tumour_purity)
  
}


