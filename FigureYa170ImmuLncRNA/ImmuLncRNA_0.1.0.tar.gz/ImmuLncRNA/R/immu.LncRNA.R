#' @title  Identify immune related lncRNAs
#' @description  \code{immu.LncRNA} aim to identify the potential lncRNA 
#'   modulators of immune-related pathways.
#' @details  \code{immu.LncRNA} identify the lncRNA modulators of the given 
#'   pathways or the defaulted immune-related pathways.First we calculated a
#'   rank score (RS) based on the output of \code{par.cor} by giving the lncRNA
#'   and gene expression and the respective samples' tumor purity. Then all
#'   genes are ranked by RS and we mapped the genes in each pathway, which you
#'   would input as a list ( or default), to the ranked genes. Based on the gene
#'   set enrichment analysis (GSEA), the enrichment score (ES) and p value were
#'   obtained. Finally we combined the p value and ES score to an lncRES score
#'   and We identify the lncRNA-pathway pairs with the absolute lncRES
#'   scores>`k` as significant ones.
#' @param mRNA_exp Numeric matrix containing the expression of mRNA with 
#'   rownames and colnames.
#' @param lncRNA_exp Numeric matrix containing the expression of lncRNA with 
#'   rownames and colnames.
#' @param adjusted Logical value. TRUE represent the expression values in 
#'   example were log-transformed and the rows containing many 0 value were 
#'   removed.If your expressions were raw, enter FALSE.
#' @param tum_put Numeric vetor represent the samples tumor purity with sample
#'   names.
#' @param pathways A list containing the immune pathways and their genes.
#' @param k Numeric value between 0 and 1,which represent the threshold of the
#'   immuPath-lncRNA pairs' significant. The higher the K value, the stricter 
#'   the filtering lncRNAs are.
#' @examples  
#' # install "estimate"
#' library(utils)
#' rforge <- "http://r-forge.r-project.org"
#' install.packages("estimate", repos=rforge, dependencies=TRUE)
#' # test for "immu.LncRNA" with data available to package
#' lncRNA_exp <- as.matrix(lncRNA_exp)
#' mRNA_exp <- as.matrix(mRNA_exp)
#' turpur_ori <- as.numeric(turpur[,1])
#' names(turpur_ori) <- rownames(turpur)
#' # check for pathway list
#' str(pathways)
#' k=0.995 
#' test_res <- immu.LncRNA(mRNA_exp,lncRNA_exp,adjusted=T,turpur_ori,pathways,k)
#' test_res$sig_pairs[1:2,] # showing the immu-lncRNA pairs
#' test_res$fgseaRes_all[1:2,] # showing the GSEA results

#' @export

immu.LncRNA <- function(mRNA_exp,lncRNA_exp,adjusted,tum_put,pathways=pathways,k=0.995){
  for(pkg in c("fgsea")){
    if(!requireNamespace(pkg,quietly=T)){
      stop(paste("The ",pkg," package needed for this function to work. Please install it.",sep=""),
           call. = FALSE)
    }
  }
  library(fgsea,warn.conflicts=F)
  lnc_ori <- as.matrix(lncRNA_exp)
  m_ori <- as.matrix(mRNA_exp)
  turpur_ori <- tum_put
  test_res <- par.cor(m_ori,lnc_ori,turpur_ori,adjusted)
  pValue_ori <- test_res$p.value
  pcorValue_ori <- test_res$pcor.value
  RS <- -log10(pValue_ori)*sign(pcorValue_ori)
  fgseaRes_all <- c()
  for(i in 1:nrow(RS)){
    ##remove the rows contain Infs
    if(sum( is.infinite(RS[i,])) != 0){
      next()
    }
    ranks <- RS[i,]
    fgseaRes <- fgsea(pathways, ranks, minSize=1, maxSize=5000, nperm=1000)
    sigValue <- c()
    for(j in 1:nrow(fgseaRes)){
      if(fgseaRes$ES[j]>0){
        sig_ij <- 1 - 2*fgseaRes$pval[j]
      }else{
        sig_ij <- 2*fgseaRes$pval[j] - 1
      }
      sigValue <- c(sigValue,sig_ij)
      
    }
    lncRNA <- rownames(RS)[i]
    fgseaRes_i <- cbind(lncRNA,fgseaRes,sigValue)
    fgseaRes_all <- rbind(fgseaRes_all,fgseaRes_i)
  }
  sig_ind <- which(abs(fgseaRes_all$sigValue) >= k)
  sig_pairs <- fgseaRes_all[sig_ind,1:2]
  sig_pairs <- as.matrix(sig_pairs)
  gsea.Res <- list(sig_pairs,fgseaRes_all)
  names(gsea.Res) <- c("sig_pairs","fgseaRes_all")
  return(gsea.Res)
}